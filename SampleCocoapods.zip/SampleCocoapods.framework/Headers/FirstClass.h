//
//  FirstClass.h
//  SampleCocoapods
//
//  Created by Saurabh Mendhe on 12/10/18.
//  Copyright © 2018 Saurabh Mendhe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FirstClass : NSObject

-(void)firstMethod;
@end
